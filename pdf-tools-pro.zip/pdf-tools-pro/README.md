# PDF Tools Pro

موقع أدوات PDF مجاني ومتكامل يعمل في المتصفح بدون خادم.

## هيكل المشروع
```
pdf-tools-pro/
├── index.html          ← الصفحة الرئيسية
├── css/style.css       ← كل التنسيقات
├── js/app.js           ← كل JavaScript
├── assets/             ← الصور والأيقونات
└── libs/               ← ضع المكتبات هنا للعمل أوفلاين
    ├── pdf-lib.min.js
    ├── pdf.min.js
    ├── pdf.worker.min.js
    └── mammoth.min.js
```

## المكتبات المطلوبة (للعمل أوفلاين)
- pdf-lib: https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js
- pdf.js:  https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js
- pdf.worker: https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js
- mammoth: https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js

## الأدوات المتاحة (16+)
- دمج، تقسيم، استخراج، حذف صفحات، إعادة الترتيب
- صور↔PDF، Word→PDF، HTML→PDF
- ضغط، تدوير (معاينة فورية)، علامة مائية (معاينة فورية)
- قص بالماوس، ترقيم الصفحات
- تشفير، فك تشفير، تثبيت
- سكانر: ارفع صور السكانر ورتبها ودمجها في PDF
- محرر مباشر: نص، تضليل، توقيع، رسم، أشكال
